package com.portfolio.bh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BhApplication {

	public static void main(String[] args) {
		SpringApplication.run(BhApplication.class, args);
	}

}
