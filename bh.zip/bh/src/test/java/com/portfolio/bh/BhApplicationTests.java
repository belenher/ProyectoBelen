package com.portfolio.bh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BhApplicationTests {

	@Test
	void contextLoads() {
	}

}
